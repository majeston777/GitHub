class Topic:
   'Common base class for all topics'
   def __init__(self, name):
      self.name = name

   